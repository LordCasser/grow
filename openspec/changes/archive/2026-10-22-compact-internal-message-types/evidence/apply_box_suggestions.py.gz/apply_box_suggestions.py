import collections,hashlib,json,pathlib,sys
root=pathlib.Path('/Users/lordcasser/workspace/projects/grow')
log=pathlib.Path(sys.argv[1]); patches=collections.defaultdict(dict)
for line in log.read_text().splitlines():
 try:d=json.loads(line)
 except ValueError:continue
 if d.get('reason')!='compiler-message':continue
 m=d['message']
 if (m.get('code') or {}).get('code')!='E0308':continue
 for child in m.get('children',[]):
  if child['message'] not in ['store this in the heap by calling `Box::new`','consider unboxing the value']:continue
  spans=child.get('spans',[])
  if not spans or any(s.get('suggestion_applicability')!='MachineApplicable'for s in spans):continue
  for s in spans:
   assert s['file_name'].startswith('crates/'),s
   p=root/s['file_name'];data=p.read_text().splitlines()
   for i,t in enumerate(s['text']):assert data[s['line_start']-1+i]==t['text'],(p,s)
   key=(s['byte_start'],s['byte_end']);v=s['suggested_replacement'];old=patches[p].get(key)
   assert old is None or old==v,(p,key,old,v)
   patches[p][key]=v
report=[]
for p,changes in patches.items():
 before=p.read_bytes();data=before;ordered=sorted(changes.items(),reverse=True);prev=len(data)+1
 for (a,b),v in ordered:
  assert b<=prev,(p,a,b,prev)
  data=data[:a]+v.encode()+data[b:];prev=a
 p.write_bytes(data);report.append({'path':str(p.relative_to(root)),'before':hashlib.sha256(before).hexdigest(),'after':hashlib.sha256(data).hexdigest(),'edits':[{'range':k,'replacement':v}for k,v in sorted(changes.items())]})
log.with_suffix('.patches.json').write_text(json.dumps(report,indent=2)+'\n')
print('files',len(report),'edits',sum(len(x['edits'])for x in report))
